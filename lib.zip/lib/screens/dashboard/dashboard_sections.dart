import 'package:flutter/material.dart';

import 'package:bio_g/screens/dashboard/dashboard_presenter.dart';
import 'package:bio_g/screens/npk/npk_screen.dart';
import 'package:bio_g/widgets/dashboard/dashboard_quick_action_card.dart';
import 'package:bio_g/widgets/insight_card.dart';
import 'package:bio_g/widgets/metric_card.dart';
import 'package:bio_g/widgets/npk_insight_card.dart';
import 'package:bio_g/widgets/shared/bio_g_glass_card.dart';
import 'package:bio_g/widgets/shared/bio_g_page_route.dart';
import 'package:bio_g/widgets/shared/bio_g_page_background.dart';
import 'package:bio_g/widgets/soil_health_ring.dart';

/// Fondo del Panel.
///
/// Desde la unificación visual delega en [BioGPageBackground], que es el mismo
/// fondo que usan las otras cuatro pestañas. Se conserva el nombre y la firma
/// para no tocar el punto de llamada del Panel.
///
/// El cielo con parallax, el velo blanco y el campo de partículas viven ahora
/// en ese widget. Aquí ya no hay pintura propia: tener dos implementaciones del
/// mismo fondo fue justamente lo que hizo que las pantallas se desincronizaran.
class DashboardBackground extends StatelessWidget {
  const DashboardBackground({super.key, this.enabled = true});

  /// True solo cuando el Panel es la pestaña visible. Ver la nota de
  /// rendimiento en [BioGPageBackground]: el `IndexedStack` mantiene las cinco
  /// pantallas vivas y solo debe animar la que se está viendo.
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return BioGPageBackground(enabled: enabled);
  }
}

class DashboardReveal extends StatelessWidget {
  final AnimationController controller;
  final double intervalStart;
  final double intervalEnd;
  final double yOffset;
  final double beginScale;
  final Widget child;

  const DashboardReveal({
    super.key,
    required this.controller,
    required this.intervalStart,
    required this.intervalEnd,
    required this.child,
    this.yOffset = 18,
    this.beginScale = 0.986,
  });

  static const Curve _premiumCurve = Cubic(0.22, 1.0, 0.36, 1.0);
  static const Curve _opacityCurve = Cubic(0.18, 0.84, 0.24, 1.0);

  @override
  Widget build(BuildContext context) {
    final CurvedAnimation positionCurve = CurvedAnimation(
      parent: controller,
      curve: Interval(intervalStart, intervalEnd, curve: _premiumCurve),
    );

    final CurvedAnimation opacityCurveAnim = CurvedAnimation(
      parent: controller,
      curve: Interval(
        intervalStart,
        intervalStart + ((intervalEnd - intervalStart) * 0.82),
        curve: _opacityCurve,
      ),
    );

    final Animation<double> opacity = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(opacityCurveAnim);

    final Animation<double> translateY = Tween<double>(
      begin: yOffset,
      end: 0.0,
    ).animate(positionCurve);

    final Animation<double> scale = Tween<double>(
      begin: beginScale,
      end: 1.0,
    ).animate(positionCurve);

    return FadeTransition(
      opacity: opacity,
      child: AnimatedBuilder(
        animation: controller,
        child: child,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, translateY.value),
            child: Transform.scale(
              scale: scale.value,
              alignment: Alignment.topCenter,
              child: child,
            ),
          );
        },
      ),
    );
  }
}

class DashboardHeaderSection extends StatelessWidget {
  final String cropLabel;
  final String fieldLabel;
  final String cropIconAsset;
  final bool hasNotifications;
  final VoidCallback? onNotificationTap;

  const DashboardHeaderSection({
    super.key,
    required this.cropLabel,
    required this.fieldLabel,
    required this.cropIconAsset,
    this.hasNotifications = false,
    this.onNotificationTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(top: 2),
          child: SizedBox(
            height: 100,
            width: double.infinity,
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: <Widget>[
                Center(
                  child: Transform.scale(
                    scale: 1.5,
                    child: Image.asset(
                      'assets/images/logo_bio_g.png',
                      height: 150,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
                if (onNotificationTap != null)
                  Positioned(
                    right: 17,
                    top: 24,
                    child: _NotificationBellButton(
                      hasNotifications: hasNotifications,
                      onTap: onNotificationTap!,
                    ),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Transform.translate(
              offset: const Offset(0, -9),
              child: SizedBox(
                width: 40,
                height: 40,
                child: Center(
                  child: Transform.scale(
                    scale: 1.7,
                    child: Image.asset(
                      cropIconAsset,
                      width: 34,
                      height: 34,
                      fit: BoxFit.contain,
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Transform.translate(
                offset: const Offset(0, -12),
                child: Text(
                  cropLabel,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Colors.black87,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Transform.translate(
                offset: const Offset(-8, -12),
                child: Text(
                  fieldLabel,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    shadows: <Shadow>[
                      Shadow(
                        blurRadius: 14,
                        color: Colors.black.withValues(alpha: 0.45),
                        offset: const Offset(0, 4),
                      ),
                      Shadow(
                        blurRadius: 4,
                        color: Colors.black.withValues(alpha: 0.35),
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class DashboardSoilHealthSection extends StatelessWidget {
  final double? percent;
  final String label;

  /// True cuando el Panel es la pestaña visible.
  ///
  /// Solo sirve para una cosa: que el arco vuelva a pintarse al entrar. Ver la
  /// nota en [SoilHealthRing.isActive] — con `IndexedStack` el `initState` del
  /// anillo corre una única vez en toda la vida de la app.
  final bool isActive;

  const DashboardSoilHealthSection({
    super.key,
    required this.percent,
    required this.label,
    this.isActive = true,
  });

  /// Lado del lienzo cuadrado de [SoilHealthRing] (`_canvas`).
  static const double _ringCanvas = 300;

  /// Lienzo muerto que se recorta por abajo.
  ///
  /// El anillo se dibuja dentro de un cuadrado de 300 px, pero lo visible no
  /// llega al borde: el aro exterior termina en 288 y el `Transform.translate`
  /// de aqui lo sube 10 mas. Eso dejaba ~22 px de aire que nadie pinta y que
  /// empujaban hacia abajo todo lo que viene despues.
  ///
  /// El tope no lo pone el aro sino la insignia: viaja por la circunferencia y
  /// al 50 % baja hasta y=297 (`_ringRadius 118 + _badgeSize/2 29`), o 287 ya
  /// con el translate. Recortar 14 deja el corte en 286, un pelo por encima de
  /// la insignia en su punto mas bajo. Pasarse de ahi la haria chocar con la
  /// tarjeta de riego en los marcadores cercanos al 50 %.
  ///
  /// `Align` no recorta pintura: solo reduce el alto que la seccion ocupa, asi
  /// que no hay riesgo de cortar el resplandor ni la sombra del aro.
  static const double _deadCanvasBottom = 14;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      heightFactor: (_ringCanvas - _deadCanvasBottom) / _ringCanvas,
      child: Transform.translate(
        offset: const Offset(0, -10),
        child: SoilHealthRing(
          percent: percent,
          label: label,
          isActive: isActive,
        ),
      ),
    );
  }
}

class DashboardTreeStatusSection extends StatelessWidget {
  final DashboardTreeStatusUiData data;

  const DashboardTreeStatusSection({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final criticalLabel = data.criticalLabel;
    final precisionLabel = data.precisionLabel;

    return BioGGlassCard(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const Icon(
                Icons.park_rounded,
                color: Color(0xFF2E7D5A),
                size: 22,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  data.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: Colors.black87,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _TreeStatusLine(text: data.stateLabel),
          _TreeStatusLine(text: data.profileLabel),
          _TreeStatusLine(text: data.stageLabel),
          _TreeStatusLine(text: data.anchorText),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: <Widget>[
              if (criticalLabel != null)
                _TreeStatusChip(
                  text: criticalLabel,
                  color: const Color(0xFFE85D4F),
                ),
              if (precisionLabel != null)
                _TreeStatusChip(
                  text: precisionLabel,
                  color: const Color(0xFF6F7F79),
                ),
            ],
          ),
          if (criticalLabel != null || precisionLabel != null)
            const SizedBox(height: 10),
          Text(
            data.priorityText,
            style: const TextStyle(
              fontSize: 13,
              height: 1.28,
              color: Color(0xFF2E7D5A),
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            data.helperText,
            style: TextStyle(
              fontSize: 13,
              height: 1.28,
              color: Colors.black.withValues(alpha: 0.62),
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _TreeStatusLine extends StatelessWidget {
  final String text;

  const _TreeStatusLine({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          fontSize: 13,
          color: Colors.black.withValues(alpha: 0.72),
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _TreeStatusChip extends StatelessWidget {
  final String text;
  final Color color;

  const _TreeStatusChip({required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: 0.18)),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: color,
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class DashboardNpkSection extends StatelessWidget {
  final String title;
  final String subtitle;
  final String tag;
  final NpkTagTone tagTone;
  final List<NpkTrendChipData> trends;

  const DashboardNpkSection({
    super.key,
    required this.title,
    required this.subtitle,
    this.tag = '',
    this.tagTone = NpkTagTone.neutral,
    this.trends = const <NpkTrendChipData>[],
  });

  @override
  Widget build(BuildContext context) {
    // Sin `Padding` propio.
    //
    // Llevaba `EdgeInsets.only(top: 12)` incrustado, que funcionaba mientras
    // esta tarjeta estuvo fija debajo del anillo. Al intercambiarla con la de
    // riego el margen viajaba con ella y descuadraba las dos posiciones a la
    // vez. La separación la decide ahora el Panel con un `SizedBox`, que es
    // donde se ve el ritmo vertical completo.
    return NpkInsightCard(
      assetIcon: 'assets/icons/metrics/ic_npk.png',
      title: title,
      subtitle: subtitle,
      tag: tag,
      tagTone: tagTone,
      trends: trends,
      onTap: () {
        Navigator.of(
          context,
        ).push(BioGPageRoute(builder: (_) => const NpkScreen()));
      },
    );
  }
}

class DashboardMetricsGridSection extends StatelessWidget {
  final DashboardMetricUiData moisture;
  final DashboardMetricUiData temperature;
  final DashboardMetricUiData ph;
  final DashboardMetricUiData resistance;
  final AnimationController controller;

  const DashboardMetricsGridSection({
    super.key,
    required this.moisture,
    required this.temperature,
    required this.ph,
    required this.resistance,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            Expanded(
              child: DashboardReveal(
                controller: controller,
                intervalStart: 0.46,
                intervalEnd: 0.62,
                yOffset: 20,
                beginScale: 0.985,
                child: MetricCard(
                  title: moisture.title,
                  value: moisture.value,
                  status: moisture.status,
                  assetIcon: moisture.assetIcon,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: DashboardReveal(
                controller: controller,
                intervalStart: 0.52,
                intervalEnd: 0.68,
                yOffset: 20,
                beginScale: 0.985,
                child: MetricCard(
                  title: temperature.title,
                  value: temperature.value,
                  status: temperature.status,
                  assetIcon: temperature.assetIcon,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: <Widget>[
            Expanded(
              child: DashboardReveal(
                controller: controller,
                intervalStart: 0.60,
                intervalEnd: 0.76,
                yOffset: 20,
                beginScale: 0.985,
                child: MetricCard(
                  title: ph.title,
                  value: ph.value,
                  status: ph.status,
                  assetIcon: ph.assetIcon,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: DashboardReveal(
                controller: controller,
                intervalStart: 0.66,
                intervalEnd: 0.84,
                yOffset: 20,
                beginScale: 0.985,
                child: MetricCard(
                  title: resistance.title,
                  value: resistance.value,
                  status: resistance.status,
                  assetIcon: resistance.assetIcon,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class DashboardQuickActionsSection extends StatelessWidget {
  final VoidCallback onExportTap;
  final VoidCallback onCropJourneyTap;
  final VoidCallback onClimateTap;
  final String cropJourneyTitle;

  const DashboardQuickActionsSection({
    super.key,
    required this.onExportTap,
    required this.onCropJourneyTap,
    required this.onClimateTap,
    this.cropJourneyTitle = 'Rendimiento\nestimado',
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        const Padding(
          padding: EdgeInsets.only(left: 2),
          child: Text(
            'Herramientas',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w800,
              color: Colors.black87,
              letterSpacing: -0.2,
            ),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 90,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Expanded(
                child: DashboardQuickActionCard(
                  assetIconPath: 'assets/icons/metrics/ic_pdf_report.png',
                  title: 'Exportar\nPDF',
                  assetScale: 4.2,
                  assetWidth: 22,
                  assetHeight: 22,
                  onTap: onExportTap,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DashboardQuickActionCard(
                  assetIconPath: 'assets/icons/metrics/ic_plant_growth.png',
                  title: cropJourneyTitle,
                  assetScale: 4.2,
                  assetWidth: 22,
                  assetHeight: 22,
                  onTap: onCropJourneyTap,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DashboardQuickActionCard(
                  assetIconPath: 'assets/icons/metrics/ic_smart_time.png',
                  title: 'Riesgos\ndel cultivo',
                  assetScale: 4.2,
                  assetWidth: 22,
                  assetHeight: 22,
                  onTap: onClimateTap,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class DashboardInsightSection extends StatelessWidget {
  final DashboardInsightUiData insight;

  const DashboardInsightSection({super.key, required this.insight});

  /// El chip de la esquina solo se pinta si dice algo que el titulo no diga ya.
  ///
  /// El presentador produce una docena de etiquetas distintas y la mayoria son
  /// eco del titulo o jerga interna: `OK` sobre "No riegues por ahora",
  /// `Regar` sobre "Riega ahora", `Setup`, `Auto`, `Mon`, `Arbol`, `—`. Cada
  /// una cuesta ~60 px de los ~240 que tiene la fila, y ese era el motivo real
  /// de que el subtitulo se cortara a media palabra: "La humedad esta por
  /// encima del ob…". El subtitulo lleva la razon agronomica, que el
  /// Fundacional 2.1 exige mostrar; el chip redundante no vale ese precio.
  ///
  /// Se conserva lo que el titulo no puede decir: la severidad (`Critica`,
  /// `Critico`, `Alerta`, `Atencion`) y el tiempo (`24h`, `Hoy`, `3d`).
  ///
  /// Para ocultarlo siempre, devuelve `null` sin mirar el valor.
  static final RegExp _informativeTag = RegExp(
    r'^(cr[ií]tic[ao]|alerta|atenci[óo]n|24h|hoy|\d+\s*d)$',
    caseSensitive: false,
  );

  String? get _visibleTag {
    final String value = insight.tag.trim();
    if (value.isEmpty) return null;
    return _informativeTag.hasMatch(value) ? value : null;
  }

  @override
  Widget build(BuildContext context) {
    return InsightCard(
      assetIcon: insight.assetIcon,
      icon: insight.icon,
      title: insight.title,
      subtitle: insight.subtitle,
      tag: _visibleTag,
    );
  }
}

class _NotificationBellButton extends StatefulWidget {
  final bool hasNotifications;
  final VoidCallback onTap;

  const _NotificationBellButton({
    required this.hasNotifications,
    required this.onTap,
  });

  @override
  State<_NotificationBellButton> createState() =>
      _NotificationBellButtonState();
}

class _NotificationBellButtonState extends State<_NotificationBellButton>
    with TickerProviderStateMixin {
  late final AnimationController _shakeController;
  late final Animation<double> _shakeAnimation;

  late final AnimationController _pulseController;
  late final Animation<double> _pulseScale;
  late final Animation<double> _pulseOpacity;

  @override
  void initState() {
    super.initState();

    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _shakeAnimation = TweenSequence<double>(
      [
        TweenSequenceItem(tween: Tween(begin: 0, end: 0.15), weight: 1),
        TweenSequenceItem(tween: Tween(begin: 0.15, end: -0.12), weight: 1),
        TweenSequenceItem(tween: Tween(begin: -0.12, end: 0.08), weight: 1),
        TweenSequenceItem(tween: Tween(begin: 0.08, end: -0.05), weight: 1),
        TweenSequenceItem(tween: Tween(begin: -0.05, end: 0), weight: 1),
      ],
    ).animate(CurvedAnimation(parent: _shakeController, curve: Curves.easeOut));

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    _pulseScale = Tween<double>(begin: 1.0, end: 1.22).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _pulseOpacity = Tween<double>(
      begin: 0.28,
      end: 0.0,
    ).animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeOut));

    if (widget.hasNotifications) {
      _startShakeLoop();
      _pulseController.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant _NotificationBellButton oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.hasNotifications && !oldWidget.hasNotifications) {
      _startShakeLoop();
      _pulseController.repeat();
    } else if (!widget.hasNotifications && oldWidget.hasNotifications) {
      _shakeController.stop();
      _shakeController.reset();
      _pulseController.stop();
      _pulseController.reset();
    }
  }

  void _startShakeLoop() {
    _shakeController.forward(from: 0).then((_) {
      if (!mounted || !widget.hasNotifications) return;
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted && widget.hasNotifications) _startShakeLoop();
      });
    });
  }

  @override
  void dispose() {
    _shakeController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: Listenable.merge(<Listenable>[
          _shakeAnimation,
          _pulseController,
        ]),
        builder: (context, child) {
          return Transform.rotate(
            angle: _shakeAnimation.value,
            child: SizedBox(
              width: 54,
              height: 54,
              child: Stack(
                clipBehavior: Clip.none,
                children: <Widget>[
                  Center(
                    child: Transform.scale(
                      scale: 1.9,
                      child: Container(
                        decoration: BoxDecoration(
                          boxShadow: <BoxShadow>[
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.10),
                              blurRadius: 12,
                              offset: const Offset(0, 1),
                            ),
                          ],
                        ),
                        child: Opacity(
                          opacity: 0.75,
                          child: Image.asset(
                            'assets/icons/metrics/ic_notification_dashboard.png',
                            width: 40,
                            height: 40,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (widget.hasNotifications)
                    Positioned(
                      right: 7,
                      top: 7,
                      child: SizedBox(
                        width: 14,
                        height: 14,
                        child: Stack(
                          alignment: Alignment.center,
                          children: <Widget>[
                            Transform.scale(
                              scale: _pulseScale.value,
                              child: Opacity(
                                opacity: _pulseOpacity.value,
                                child: Container(
                                  width: 14,
                                  height: 14,
                                  decoration: const BoxDecoration(
                                    color: Color(0xFFFF4D4F),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: 9,
                              height: 9,
                              decoration: BoxDecoration(
                                color: const Color(0xFFFF4D4F),
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: Colors.white,
                                  width: 1.2,
                                ),
                                boxShadow: <BoxShadow>[
                                  BoxShadow(
                                    color: const Color(
                                      0xFFFF4D4F,
                                    ).withValues(alpha: 0.45),
                                    blurRadius: 8,
                                    spreadRadius: 1,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
