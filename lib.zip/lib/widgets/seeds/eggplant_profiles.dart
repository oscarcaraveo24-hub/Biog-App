import 'package:bio_g/widgets/seeds/eggplant_models.dart';
import 'package:bio_g/widgets/seeds/maize_models.dart';

const String kBeGen = 'be_gen';
const String kBe01 = 'be_01';
const String kBe02 = 'be_02';
const String kBe03 = 'be_03';
const String kBe04 = 'be_04';

const Map<String, EggplantProfile> eggplantProfiles = {
  kBeGen: EggplantProfile(
    id: kBeGen,
    label: 'BE-GEN - Berenjena generica',
    useType: 'Fruto fresco generico',
    marketType: EggplantMarketType.generic,
    defaultEstablishmentMode: EggplantEstablishmentMode.transplant,
    // PDF Perfil Universal v2: floracion 45-65 DAT, cosecha 70-95 DAT.
    floweringDays: RangeInt(45, 65),
    harvestStartDays: RangeInt(70, 95),
    endWindowDays: RangeInt(145, 205),
    endActionLabel: 'Cierre conservador',
    plantHeightM: RangeDouble(0.70, 1.25),
    densityPlantsPerHa: RangeInt(12000, 20000),
    referenceYieldTHa: RangeDouble(18, 32),
    isGenericProfile: true,
  ),
  kBe01: EggplantProfile(
    id: kBe01,
    label: 'BE-01 - Berenjena larga / semilarga morada',
    useType: 'Fruto fresco',
    marketType: EggplantMarketType.longPurple,
    defaultEstablishmentMode: EggplantEstablishmentMode.transplant,
    // PDF Perfil Universal v2: floracion 40-60 DAT, cosecha 65-90 DAT.
    floweringDays: RangeInt(40, 60),
    harvestStartDays: RangeInt(65, 90),
    endWindowDays: RangeInt(150, 215),
    endActionLabel: 'Cierre de cosecha progresiva',
    plantHeightM: RangeDouble(0.80, 1.40),
    densityPlantsPerHa: RangeInt(14000, 22000),
    referenceYieldTHa: RangeDouble(25, 45),
  ),
  kBe02: EggplantProfile(
    id: kBe02,
    label: 'BE-02 - Berenjena oval / bola morada',
    useType: 'Fruto fresco',
    marketType: EggplantMarketType.ovalRound,
    defaultEstablishmentMode: EggplantEstablishmentMode.transplant,
    // PDF Perfil Universal v2: floracion 45-65 DAT, cosecha 70-95 DAT.
    floweringDays: RangeInt(45, 65),
    harvestStartDays: RangeInt(70, 95),
    endWindowDays: RangeInt(150, 215),
    endActionLabel: 'Cierre de cosecha progresiva',
    plantHeightM: RangeDouble(0.75, 1.35),
    densityPlantsPerHa: RangeInt(12000, 20000),
    referenceYieldTHa: RangeDouble(22, 42),
  ),
  kBe03: EggplantProfile(
    id: kBe03,
    label: 'BE-03 - Berenjena rayada / listada',
    useType: 'Fruto fresco nicho',
    marketType: EggplantMarketType.striped,
    defaultEstablishmentMode: EggplantEstablishmentMode.transplant,
    // PDF Perfil Universal v2: floracion 45-70 DAT, cosecha 75-105 DAT.
    floweringDays: RangeInt(45, 70),
    harvestStartDays: RangeInt(75, 105),
    endWindowDays: RangeInt(145, 205),
    endActionLabel: 'Cierre de cosecha de calidad visual',
    plantHeightM: RangeDouble(0.70, 1.25),
    densityPlantsPerHa: RangeInt(12000, 20000),
    referenceYieldTHa: RangeDouble(16, 32),
    visualQualitySensitive: true,
  ),
  kBe04: EggplantProfile(
    id: kBe04,
    label: 'BE-04 - Berenjena blanca',
    useType: 'Fruto fresco nicho',
    marketType: EggplantMarketType.white,
    defaultEstablishmentMode: EggplantEstablishmentMode.transplant,
    // PDF Perfil Universal v2: floracion 45-70 DAT, cosecha 75-105 DAT.
    floweringDays: RangeInt(45, 70),
    harvestStartDays: RangeInt(75, 105),
    endWindowDays: RangeInt(145, 205),
    endActionLabel: 'Cierre de cosecha de calidad visual',
    plantHeightM: RangeDouble(0.65, 1.20),
    densityPlantsPerHa: RangeInt(12000, 20000),
    referenceYieldTHa: RangeDouble(14, 30),
    visualQualitySensitive: true,
  ),
};

const Map<String, String> _eggplantProfileAliasToCanonical = {
  'be-gen': kBeGen,
  'begen': kBeGen,
  'be_gen': kBeGen,
  'generica': kBeGen,
  'generico': kBeGen,
  'generic': kBeGen,
  'berenjena generica': kBeGen,
  'otra berenjena': kBeGen,
  'no se': kBeGen,
  'skip': kBeGen,

  'be-01': kBe01,
  'be01': kBe01,
  'be_01': kBe01,
  'larga': kBe01,
  'semilarga': kBe01,
  'morada larga': kBe01,
  'larga morada': kBe01,
  'barcelona': kBe01,
  'dark night': kBe01,
  'orestia': kBe01,
  'napoli': kBe01,

  'be-02': kBe02,
  'be02': kBe02,
  'be_02': kBe02,
  'oval': kBe02,
  'bola': kBe02,
  'bola morada': kBe02,
  'oval morada': kBe02,
  'night shadow': kBe02,
  'emma f1': kBe02,

  'be-03': kBe03,
  'be03': kBe03,
  'be_03': kBe03,
  'rayada': kBe03,
  'listada': kBe03,
  'graffiti': kBe03,
  'grafiti': kBe03,

  'be-04': kBe04,
  'be04': kBe04,
  'be_04': kBe04,
  'blanca': kBe04,
  'white egg': kBe04,
  'blanca f1': kBe04,
};

String? resolveCanonicalEggplantProfileId(String raw) {
  final normalized = raw.trim().toLowerCase();
  if (normalized.isEmpty) return null;
  if (eggplantProfiles.containsKey(normalized)) return normalized;
  return _eggplantProfileAliasToCanonical[normalized];
}
