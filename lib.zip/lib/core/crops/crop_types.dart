enum CropCategory { grain, vegetable, fruit, ornamental, tree }

enum CropKey {
  maize,
  wheat,
  barley,
  bean,
  oat,
  tomato,
  cucumber,
  chili,
  eggplant,
  squash,
  lettuce,
  spinach,
  onion,
  garlic,
  appleTree,
  pearTree,
  peachTree,
  generic,
}
