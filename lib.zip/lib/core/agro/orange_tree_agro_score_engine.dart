import 'package:bio_g/core/agro/agro_types.dart';
import 'package:bio_g/core/agro/alerts_engine.dart';
import 'package:bio_g/core/agro/tree_agro_score_engine.dart';
import 'package:bio_g/core/crops/crop_target_models.dart';
import 'package:bio_g/models/biog_telemetry.dart';

/// Motor AgroScore del Naranjo.
///
/// Delega en el motor generico [TreeAgroScoreEngine] (mismo pipeline perenne que
/// manzano/pera/durazno/nogal/pistache), aportando su `cropKey`. No duplica
/// logica base: solo aporta la identidad del cultivo (doc 05 §1, §20).
///
/// Desde el NPK Interpretation Reset (Guía v0.4, §4) este wrapper ya no resuelve
/// el modificador nutricional de la variedad: el score del árbol no interpreta
/// N/P/K. El modificador sigue existiendo y lo consume el motor de nutrición.
class OrangeTreeAgroScoreEngine {
  const OrangeTreeAgroScoreEngine._();

  /// Etapas criticas (mas peso al estres en alertas/score).
  static const Set<String> criticalStages = TreeAgroScoreEngine.criticalStages;

  /// Etapas semicriticas.
  static const Set<String> semiCriticalStages =
      TreeAgroScoreEngine.semiCriticalStages;

  static ({AgroEvalResult eval, AlertsState nextAlertsState}) evaluate({
    required BioGTelemetry t,
    required String stageId,
    required String stageLabelEs,
    required StageTargets targets,
    required StageWeights weights,
    AlertsState alertsState = const AlertsState(),
    Calibration? cal,
    Duration alertsCooldown = AlertsEngine.defaultCooldown,
    String? cropLabel,
    String? profileId,
    String? varietyId,
    String? varietyAlias,
  }) {
    return TreeAgroScoreEngine.evaluate(
      t: t,
      cropKey: 'orange_tree',
      stageId: stageId,
      stageLabelEs: stageLabelEs,
      targets: targets,
      weights: weights,
      alertsState: alertsState,
      cal: cal,
      alertsCooldown: alertsCooldown,
      cropLabel: cropLabel ?? 'Naranjo',
      profileId: profileId,
      varietyId: varietyId,
      varietyAlias: varietyAlias,
    );
  }
}
