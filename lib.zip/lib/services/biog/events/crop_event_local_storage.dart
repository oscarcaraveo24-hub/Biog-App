import 'dart:convert';

import 'package:bio_g/core/agro/agronomic_event.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Memoria persistente de los eventos del cultivo.
///
/// Hasta ahora los eventos se recalculaban dentro del `build()` de la pantalla
/// y no se guardaban en ningún lado. La consecuencia práctica: si el cultivo
/// cambiaba de etapa a las tres de la madrugada y el agricultor no tenía la app
/// abierta en ese instante, ese evento **nunca existió**. El Historial no era
/// memoria del cultivo, era una foto del momento.
///
/// Esta clase no cambia nada de lo que se ve en pantalla: solo conserva lo que
/// ya se calcula, para que sobreviva a cerrar la app. Es además el requisito
/// para que más adelante una notificación pueda sonar sin la app abierta.
///
/// Usa su propio archivo de base de datos, separado del de telemetría, para no
/// tocar un almacenamiento que ya está en uso.
class CropEventLocalStorage {
  static const String _dbName = 'biog_crop_events.db';
  static const String _table = 'crop_events';

  static Future<Database>? _dbFuture;

  Future<Database> get _db => _dbFuture ??= _openDb();

  static Future<Database> _openDb() async {
    final String dir = await getDatabasesPath();
    return openDatabase(
      p.join(dir, _dbName),
      version: 1,
      onCreate: (Database db, int version) async {
        await db.execute('''
          CREATE TABLE $_table (
            device_id TEXT NOT NULL,
            dedup_key TEXT NOT NULL,
            ts INTEGER NOT NULL,
            payload TEXT NOT NULL,
            PRIMARY KEY (device_id, dedup_key)
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_${_table}_device_ts ON $_table (device_id, ts DESC)',
        );
      },
    );
  }

  /// Guarda los eventos que todavía no estaban registrados.
  ///
  /// Usa `INSERT OR IGNORE` contra la llave de deduplicación: recalcular la
  /// misma lectura mil veces no genera mil filas. Devuelve cuántos eran nuevos.
  Future<int> saveNew(String deviceId, List<AgronomicEvent> events) async {
    if (events.isEmpty) return 0;
    try {
      final Database db = await _db;
      int inserted = 0;

      await db.transaction((Transaction txn) async {
        for (final AgronomicEvent e in events) {
          final int n = await txn.rawInsert(
            'INSERT OR IGNORE INTO $_table '
            '(device_id, dedup_key, ts, payload) VALUES (?, ?, ?, ?)',
            <Object?>[
              deviceId,
              e.dedupKey,
              e.timestamp.toUtc().millisecondsSinceEpoch,
              jsonEncode(e.toJson()),
            ],
          );
          if (n > 0) inserted++;
        }
      });

      return inserted;
    } catch (_) {
      // Guardar el historial de eventos nunca puede afectar a la app.
      return 0;
    }
  }

  /// Eventos registrados de un dispositivo, del más reciente al más antiguo.
  Future<List<AgronomicEvent>> load(String deviceId, {int limit = 500}) async {
    try {
      final Database db = await _db;
      final List<Map<String, Object?>> rows = await db.query(
        _table,
        columns: <String>['payload'],
        where: 'device_id = ?',
        whereArgs: <Object?>[deviceId],
        orderBy: 'ts DESC',
        limit: limit,
      );

      final List<AgronomicEvent> out = <AgronomicEvent>[];
      for (final Map<String, Object?> row in rows) {
        final Object? raw = row['payload'];
        if (raw is! String) continue;
        try {
          final AgronomicEvent? e = AgronomicEvent.fromJson(
            jsonDecode(raw) as Map<String, dynamic>,
          );
          if (e != null) out.add(e);
        } catch (_) {
          // Fila ilegible: se ignora sin tumbar la consulta.
        }
      }
      return out;
    } catch (_) {
      return <AgronomicEvent>[];
    }
  }

  /// Cuántos eventos hay registrados para un dispositivo.
  Future<int> count(String deviceId) async {
    try {
      final Database db = await _db;
      final List<Map<String, Object?>> rows = await db.rawQuery(
        'SELECT COUNT(*) AS c FROM $_table WHERE device_id = ?',
        <Object?>[deviceId],
      );
      final Object? c = rows.isEmpty ? null : rows.first['c'];
      return c is int ? c : 0;
    } catch (_) {
      return 0;
    }
  }

  /// Borra los eventos de un dispositivo.
  Future<void> delete(String deviceId) async {
    try {
      final Database db = await _db;
      await db.delete(
        _table,
        where: 'device_id = ?',
        whereArgs: <Object?>[deviceId],
      );
    } catch (_) {
      // Ídem.
    }
  }
}
