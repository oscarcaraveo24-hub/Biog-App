import 'package:bio_g/core/agro/agronomic_event.dart';
import 'package:bio_g/core/crops/crop_runtime_resolver.dart';
import 'package:bio_g/core/crops/crop_runtime_snapshot.dart';
import 'package:bio_g/models/biog_telemetry.dart';
import 'package:bio_g/screens/history/history_presenter.dart';
import 'package:bio_g/services/biog/biog_store.dart';
import 'package:bio_g/services/biog/events/crop_event_local_storage.dart';
import 'package:bio_g/services/biog/storage/telemetry_local_storage.dart';

/// Registra los eventos del cultivo para que existan aunque nadie tenga la
/// pantalla abierta.
///
/// Decisión de diseño deliberada: **reutiliza el mismo cálculo del Historial**,
/// `HistoryScreenPresenter.buildAgronomicEvents`, en lugar de reimplementarlo.
/// Ese presenter es una clase pura —constructor `const`, sin `BuildContext`, sin
/// dependencias de widget— así que puede llamarse desde aquí sin problema.
///
/// La razón de reusarlo y no copiarlo: garantiza que lo que se guarda sea
/// **idéntico** a lo que el agricultor ve en el Historial. Si algún día se
/// afinan las reglas de eventos, se afinan en un solo lugar y ambos siguen
/// coincidiendo. Duplicar la lógica habría creado dos verdades que se separan
/// con el tiempo.
///
/// Nada de esto altera el comportamiento visible: ni el Panel ni el Historial
/// cambian. Solo se agrega memoria.
class CropEventRecorder {
  CropEventRecorder({
    CropEventLocalStorage? storage,
    TelemetryLocalStorage? telemetryStorage,
  }) : _storage = storage ?? CropEventLocalStorage(),
       _telemetryStorage = telemetryStorage ?? TelemetryLocalStorage();

  static const HistoryScreenPresenter _presenter = HistoryScreenPresenter();

  final CropEventLocalStorage _storage;
  final TelemetryLocalStorage _telemetryStorage;

  /// Evita recalcular sobre la misma lectura si el store notifica varias veces.
  String? _lastSignature;

  /// Impide que dos registros se solapen si llegan lecturas seguidas.
  bool _running = false;

  CropEventLocalStorage get storage => _storage;

  /// Calcula y guarda los eventos nuevos a partir del estado actual del store.
  ///
  /// Es seguro llamarlo con cualquier frecuencia: si nada cambió desde la
  /// última vez, sale sin tocar disco. Cualquier fallo se traga a propósito —
  /// registrar la memoria del cultivo jamás debe interrumpir al usuario.
  Future<void> recordFromStore(BioGStore store) async {
    if (_running) return;

    final String? deviceId = store.activeDevice?.id;
    final BioGTelemetry? live = store.live;
    if (deviceId == null || live == null) return;

    // Firma del estado: si la lectura y el contexto son los mismos, no hay
    // eventos nuevos que calcular.
    final String signature = <Object?>[
      deviceId,
      live.timestamp.toUtc().millisecondsSinceEpoch,
      store.activeCropContext?.cropId,
      store.activeCropContext?.updatedAt.millisecondsSinceEpoch,
    ].join('|');
    if (signature == _lastSignature) return;

    _running = true;
    try {
      final String? telemetryId = store.activeDevice?.telemetryDeviceId;
      final List<BioGTelemetry> history = telemetryId == null
          ? const <BioGTelemetry>[]
          : await _telemetryStorage.load(telemetryId);

      final CropRuntimeSnapshot runtime = CropRuntimeResolver.resolve(
        device: store.activeDevice,
        seed: store.activeSeed,
        cropContext: store.activeCropContext,
        live: live,
        alertsState: store.alertsState,
      );

      final List<AgronomicEvent> events = _presenter.buildAgronomicEvents(
        store: store,
        runtime: runtime,
        telemetry: history,
      );

      await _storage.saveNew(deviceId, events);
      _lastSignature = signature;
    } catch (_) {
      // Silencio deliberado: este registro es memoria, no funcionalidad. Si
      // falla, el agricultor no debe enterarse ni ver nada distinto.
    } finally {
      _running = false;
    }
  }

  /// Limpia la firma al cambiar de usuario o de dispositivo activo.
  void reset() {
    _lastSignature = null;
  }
}
