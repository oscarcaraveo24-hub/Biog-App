import 'dart:convert';

enum CropLifecycleStatus { planned, planted, fallow }

enum DateConfidence { exact, estimated, unknown }

enum CropConfigSource { wizard, manualEdit, demo, imported }

class DeviceCropContext {
  final String deviceId;

  // identidad de catálogo
  final String cropCategoryId; // grain
  final String cropId; // maize
  final String profileId; // maize_generic, maize_mid, etc.
  final String? brandId; // dekalb, pioneer (solo maíz v1)
  final String? varietyId; // dekalb_dk2069_grain
  final String? varietyAlias; // visible label (DK-2069)
  final String? calendarTypeId; // pv, oi, riego, temporal

  // estado operativo
  final CropLifecycleStatus lifecycleStatus;
  final DateTime? sowingDate;
  final DateTime? plannedSowingDate;
  final DateConfidence sowingDateConfidence;

  // escala operativa
  final String? cultivationScaleId; // field, bed, pot

  // contexto adicional
  final String? sowingModeId; // rainfed / irrigated
  final String? timezone;
  final String? regionCode;
  final String? cycleLabel;

  /// Modo de establecimiento: siembra_directa | trasplante.
  ///
  /// Opcional; relevante para cultivos como tomate donde cambia el anclaje
  /// temporal del ciclo (el reloj biológico arranca en trasplante, no en
  /// semilla). Grano tradicional no lo usa.
  final String? establishmentModeId;

  // ── Contexto perenne (árboles/frutales) ─────────────────────────────────────
  //
  // Campos nullable usados solo por la categoría Árbol. Los cultivos anuales
  // (grano/hortaliza) los dejan en null y su semántica no cambia. La condición
  // "es perenne" NO se persiste: se deriva de cropCategoryId == tree (ver
  // CropCategory.tree). Estos campos quedan estructurados para la Fase 2 del
  // runtime perenne; en esta fase no alteran comportamiento.

  /// Estado fisiológico del perenne (p. ej. dormancia, brotación, crecimiento).
  /// No aplica a anuales.
  final String? perennialStateId;

  /// Etapa fenológica visible del ciclo productivo anual del árbol.
  /// No aplica a anuales.
  final String? phenologyStageId;

  /// Fecha de anclaje del ciclo perenne (no es fecha de siembra). El reloj de un
  /// árbol no arranca en siembra ni "termina"; el ciclo productivo se reinicia.
  /// No reutilizar [sowingDate] para árboles.
  final DateTime? perennialAnchorDate;

  /// Tipo del anclaje perenne (p. ej. brotación, floración, plantación).
  /// Acompaña a [perennialAnchorDate]. No aplica a anuales.
  final String? perennialAnchorTypeId;

  // ── Contexto ornamental (establecimiento + mantenimiento) ────────────────
  // Campos aditivos y nullable. No reutilizan la semántica fenológica de los
  // árboles y no alteran contextos anuales o perennes existentes.

  final String? lifecycleModeId;
  final String? ornamentalStageId;
  final DateTime? ornamentalAnchorDate;
  final String? ornamentalAnchorTypeId;
  final DateConfidence? ornamentalAnchorDateConfidence;
  final double? ornamentalStageConfidence;

  // trazabilidad
  final String catalogVersion;
  final CropConfigSource source;
  final DateTime configuredAt;
  final DateTime updatedAt;

  const DeviceCropContext({
    required this.deviceId,
    required this.cropCategoryId,
    required this.cropId,
    required this.profileId,
    required this.lifecycleStatus,
    required this.sowingDateConfidence,
    required this.catalogVersion,
    required this.source,
    required this.configuredAt,
    required this.updatedAt,
    this.brandId,
    this.varietyId,
    this.varietyAlias,
    this.calendarTypeId,
    this.sowingDate,
    this.plannedSowingDate,
    this.cultivationScaleId,
    this.sowingModeId,
    this.timezone,
    this.regionCode,
    this.cycleLabel,
    this.establishmentModeId,
    this.perennialStateId,
    this.phenologyStageId,
    this.perennialAnchorDate,
    this.perennialAnchorTypeId,
    this.lifecycleModeId,
    this.ornamentalStageId,
    this.ornamentalAnchorDate,
    this.ornamentalAnchorTypeId,
    this.ornamentalAnchorDateConfidence,
    this.ornamentalStageConfidence,
  });

  DeviceCropContext copyWith({
    String? deviceId,
    String? cropCategoryId,
    String? cropId,
    String? profileId,
    Object? brandId = _sentinel,
    Object? varietyId = _sentinel,
    Object? varietyAlias = _sentinel,
    Object? calendarTypeId = _sentinel,
    CropLifecycleStatus? lifecycleStatus,
    Object? sowingDate = _sentinel,
    Object? plannedSowingDate = _sentinel,
    DateConfidence? sowingDateConfidence,
    Object? cultivationScaleId = _sentinel,
    Object? sowingModeId = _sentinel,
    Object? timezone = _sentinel,
    Object? regionCode = _sentinel,
    Object? cycleLabel = _sentinel,
    Object? establishmentModeId = _sentinel,
    Object? perennialStateId = _sentinel,
    Object? phenologyStageId = _sentinel,
    Object? perennialAnchorDate = _sentinel,
    Object? perennialAnchorTypeId = _sentinel,
    Object? lifecycleModeId = _sentinel,
    Object? ornamentalStageId = _sentinel,
    Object? ornamentalAnchorDate = _sentinel,
    Object? ornamentalAnchorTypeId = _sentinel,
    Object? ornamentalAnchorDateConfidence = _sentinel,
    Object? ornamentalStageConfidence = _sentinel,
    String? catalogVersion,
    CropConfigSource? source,
    DateTime? configuredAt,
    DateTime? updatedAt,
  }) {
    return DeviceCropContext(
      deviceId: deviceId ?? this.deviceId,
      cropCategoryId: cropCategoryId ?? this.cropCategoryId,
      cropId: cropId ?? this.cropId,
      profileId: profileId ?? this.profileId,
      brandId: identical(brandId, _sentinel)
          ? this.brandId
          : brandId as String?,
      varietyId: identical(varietyId, _sentinel)
          ? this.varietyId
          : varietyId as String?,
      varietyAlias: identical(varietyAlias, _sentinel)
          ? this.varietyAlias
          : varietyAlias as String?,
      calendarTypeId: identical(calendarTypeId, _sentinel)
          ? this.calendarTypeId
          : calendarTypeId as String?,
      lifecycleStatus: lifecycleStatus ?? this.lifecycleStatus,
      sowingDate: identical(sowingDate, _sentinel)
          ? this.sowingDate
          : sowingDate as DateTime?,
      plannedSowingDate: identical(plannedSowingDate, _sentinel)
          ? this.plannedSowingDate
          : plannedSowingDate as DateTime?,
      sowingDateConfidence: sowingDateConfidence ?? this.sowingDateConfidence,
      cultivationScaleId: identical(cultivationScaleId, _sentinel)
          ? this.cultivationScaleId
          : cultivationScaleId as String?,
      sowingModeId: identical(sowingModeId, _sentinel)
          ? this.sowingModeId
          : sowingModeId as String?,
      timezone: identical(timezone, _sentinel)
          ? this.timezone
          : timezone as String?,
      regionCode: identical(regionCode, _sentinel)
          ? this.regionCode
          : regionCode as String?,
      cycleLabel: identical(cycleLabel, _sentinel)
          ? this.cycleLabel
          : cycleLabel as String?,
      establishmentModeId: identical(establishmentModeId, _sentinel)
          ? this.establishmentModeId
          : establishmentModeId as String?,
      perennialStateId: identical(perennialStateId, _sentinel)
          ? this.perennialStateId
          : perennialStateId as String?,
      phenologyStageId: identical(phenologyStageId, _sentinel)
          ? this.phenologyStageId
          : phenologyStageId as String?,
      perennialAnchorDate: identical(perennialAnchorDate, _sentinel)
          ? this.perennialAnchorDate
          : perennialAnchorDate as DateTime?,
      perennialAnchorTypeId: identical(perennialAnchorTypeId, _sentinel)
          ? this.perennialAnchorTypeId
          : perennialAnchorTypeId as String?,
      lifecycleModeId: identical(lifecycleModeId, _sentinel)
          ? this.lifecycleModeId
          : lifecycleModeId as String?,
      ornamentalStageId: identical(ornamentalStageId, _sentinel)
          ? this.ornamentalStageId
          : ornamentalStageId as String?,
      ornamentalAnchorDate: identical(ornamentalAnchorDate, _sentinel)
          ? this.ornamentalAnchorDate
          : ornamentalAnchorDate as DateTime?,
      ornamentalAnchorTypeId: identical(ornamentalAnchorTypeId, _sentinel)
          ? this.ornamentalAnchorTypeId
          : ornamentalAnchorTypeId as String?,
      ornamentalAnchorDateConfidence:
          identical(ornamentalAnchorDateConfidence, _sentinel)
          ? this.ornamentalAnchorDateConfidence
          : ornamentalAnchorDateConfidence as DateConfidence?,
      ornamentalStageConfidence: identical(ornamentalStageConfidence, _sentinel)
          ? this.ornamentalStageConfidence
          : ornamentalStageConfidence as double?,
      catalogVersion: catalogVersion ?? this.catalogVersion,
      source: source ?? this.source,
      configuredAt: configuredAt ?? this.configuredAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'deviceId': deviceId,
      'cropCategoryId': cropCategoryId,
      'cropId': cropId,
      'profileId': profileId,
      'brandId': brandId,
      'varietyId': varietyId,
      'varietyAlias': varietyAlias,
      'calendarTypeId': calendarTypeId,
      'lifecycleStatus': lifecycleStatus.name,
      'sowingDate': sowingDate?.toIso8601String(),
      'plannedSowingDate': plannedSowingDate?.toIso8601String(),
      'sowingDateConfidence': sowingDateConfidence.name,
      'cultivationScaleId': cultivationScaleId,
      'sowingModeId': sowingModeId,
      'timezone': timezone,
      'regionCode': regionCode,
      'cycleLabel': cycleLabel,
      'establishmentModeId': establishmentModeId,
      'perennialStateId': perennialStateId,
      'phenologyStageId': phenologyStageId,
      'perennialAnchorDate': perennialAnchorDate?.toIso8601String(),
      'perennialAnchorTypeId': perennialAnchorTypeId,
      'lifecycleModeId': lifecycleModeId,
      'ornamentalStageId': ornamentalStageId,
      'ornamentalAnchorDate': ornamentalAnchorDate?.toIso8601String(),
      'ornamentalAnchorTypeId': ornamentalAnchorTypeId,
      'ornamentalAnchorDateConfidence': ornamentalAnchorDateConfidence?.name,
      'ornamentalStageConfidence': ornamentalStageConfidence,
      'catalogVersion': catalogVersion,
      'source': source.name,
      'configuredAt': configuredAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory DeviceCropContext.fromJson(Map<String, dynamic> json) {
    final String rawCropId = json['cropId'] as String;
    final String normalizedCropId = rawCropId.trim().toLowerCase();
    final String rawCategoryId = json['cropCategoryId'] as String;
    final String rawProfileId = json['profileId'] as String;
    final String normalizedProfileId = rawProfileId.trim().toLowerCase();
    // La categoría ornamental por sí sola no identifica Cactus: una rosa u
    // otra ornamental futura nunca debe migrar a crop_cactus por compartir un
    // prefijo de perfil accidental. Solo aceptamos IDs/aliases del cultivo.
    final bool isCactus = <String>{
      'crop_cactus',
      'cactus',
      'cactos',
      'cacto',
      'cactus ornamental',
      'cactus desertico',
      'cactus desértico',
      'cactaceae',
      'cactacea',
      'cactácea',
      'cactus_generic',
      'cactus_mini',
      'cactus_columnar',
    }.contains(normalizedCropId);

    final String canonicalProfileId = isCactus
        ? _resolvePersistedCactusProfileId(
            profileId: normalizedProfileId,
            varietyId: json['varietyId'] as String?,
            varietyAlias: json['varietyAlias'] as String?,
          )
        : rawProfileId;

    DateTime? parseDate(Object? raw) =>
        raw is String && raw.isNotEmpty ? DateTime.parse(raw) : null;

    final String? legacyCactusStage = isCactus
        ? json['perennialStateId'] as String?
        : null;
    final DateTime? legacyCactusAnchor = isCactus
        ? parseDate(json['perennialAnchorDate'])
        : null;
    final String? legacyCactusAnchorType = isCactus
        ? json['perennialAnchorTypeId'] as String?
        : null;
    final DateTime? legacyCactusSowingDate = isCactus
        ? parseDate(json['sowingDate'])
        : null;
    final CropLifecycleStatus rawLifecycleStatus = CropLifecycleStatus.values
        .byName(json['lifecycleStatus'] as String);
    return DeviceCropContext(
      deviceId: json['deviceId'] as String,
      cropCategoryId: isCactus ? 'ornamental' : rawCategoryId,
      cropId: isCactus ? 'crop_cactus' : rawCropId,
      profileId: canonicalProfileId,
      brandId: json['brandId'] as String?,
      // Para Cactus el profileId también es el id canónico de la opción
      // elegida. Conservarlo aquí evita que un roundtrip borre la variedad y
      // obligue al runtime a caer en ca_skip.
      varietyId: isCactus ? canonicalProfileId : json['varietyId'] as String?,
      varietyAlias: isCactus
          ? _canonicalCactusVisibleAlias(
              json['varietyAlias'] as String?,
              canonicalProfileId,
            )
          : json['varietyAlias'] as String?,
      calendarTypeId: json['calendarTypeId'] as String?,
      lifecycleStatus:
          isCactus && rawLifecycleStatus == CropLifecycleStatus.fallow
          ? CropLifecycleStatus.planted
          : rawLifecycleStatus,
      sowingDate: isCactus || json['sowingDate'] == null
          ? null
          : DateTime.parse(json['sowingDate'] as String),
      plannedSowingDate: isCactus || json['plannedSowingDate'] == null
          ? null
          : DateTime.parse(json['plannedSowingDate'] as String),
      sowingDateConfidence: DateConfidence.values.byName(
        json['sowingDateConfidence'] as String,
      ),
      cultivationScaleId: isCactus
          ? null
          : json['cultivationScaleId'] as String?,
      sowingModeId: isCactus ? null : json['sowingModeId'] as String?,
      timezone: json['timezone'] as String?,
      regionCode: json['regionCode'] as String?,
      cycleLabel: json['cycleLabel'] as String?,
      establishmentModeId: json['establishmentModeId'] as String?,
      // Contextos antiguos no traen estas claves: quedan null de forma segura.
      perennialStateId: isCactus ? null : json['perennialStateId'] as String?,
      phenologyStageId: isCactus ? null : json['phenologyStageId'] as String?,
      perennialAnchorDate: isCactus
          ? null
          : parseDate(json['perennialAnchorDate']),
      perennialAnchorTypeId: isCactus
          ? null
          : json['perennialAnchorTypeId'] as String?,
      lifecycleModeId:
          json['lifecycleModeId'] as String? ??
          (isCactus ? 'establishment_maintenance' : null),
      ornamentalStageId: isCactus
          ? _canonicalCactusStageId(
              json['ornamentalStageId'] as String? ?? legacyCactusStage,
            )
          : json['ornamentalStageId'] as String?,
      ornamentalAnchorDate:
          parseDate(json['ornamentalAnchorDate']) ??
          legacyCactusAnchor ??
          legacyCactusSowingDate,
      ornamentalAnchorTypeId:
          json['ornamentalAnchorTypeId'] as String? ?? legacyCactusAnchorType,
      ornamentalAnchorDateConfidence:
          _dateConfidenceOrNull(json['ornamentalAnchorDateConfidence']) ??
          (isCactus
              ? DateConfidence.values.byName(
                  json['sowingDateConfidence'] as String,
                )
              : null),
      ornamentalStageConfidence:
          (json['ornamentalStageConfidence'] as num?)?.toDouble() ??
          (isCactus ? 0.25 : null),
      catalogVersion: json['catalogVersion'] as String,
      source: CropConfigSource.values.byName(json['source'] as String),
      configuredAt: DateTime.parse(json['configuredAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
    );
  }

  String encode() => jsonEncode(toJson());

  factory DeviceCropContext.decode(String raw) {
    return DeviceCropContext.fromJson(jsonDecode(raw) as Map<String, dynamic>);
  }
}

const Object _sentinel = Object();

DateConfidence? _dateConfidenceOrNull(Object? raw) {
  if (raw is! String || raw.isEmpty) return null;
  try {
    return DateConfidence.values.byName(raw);
  } catch (_) {
    return null;
  }
}

String _canonicalCactusProfileId(String value) {
  return _canonicalCactusProfileIdOrNull(value) ?? 'ca_skip';
}

String? _canonicalCactusProfileIdOrNull(String? value) {
  return switch (value?.trim().toLowerCase()) {
    'ca_skip' ||
    'ca-skip' ||
    'caskip' ||
    'cactus' ||
    'cactus general' ||
    'no sé / cactus general' ||
    'no se / cactus general' ||
    'cactus_generic' => 'ca_skip',
    'ca_01_desert_container' ||
    'ca-01' ||
    'ca01' ||
    'ca_01' ||
    'cactus de maceta' ||
    'cactus mini' ||
    'cactus_mini' => 'ca_01_desert_container',
    'ca_02_barrel_biznaga' ||
    'ca-02' ||
    'ca02' ||
    'ca_02' ||
    'biznaga' ||
    'cactus barril' ||
    'biznaga o cactus barril' => 'ca_02_barrel_biznaga',
    'ca_03_columnar_landscape' ||
    'ca-03' ||
    'ca03' ||
    'ca_03' ||
    'cactus columna' ||
    'cactus columna u órgano' ||
    'cactus columnar u órgano' ||
    'cactus_columnar' => 'ca_03_columnar_landscape',
    'ca_04_clustered_desert' ||
    'ca-04' ||
    'ca04' ||
    'ca_04' ||
    'cactus agrupado' ||
    'cactus agrupado o ramificado' ||
    'cactus agrupado o de varios tallos' => 'ca_04_clustered_desert',
    _ => null,
  };
}

String _resolvePersistedCactusProfileId({
  required String profileId,
  String? varietyId,
  String? varietyAlias,
}) {
  final fromProfile = _canonicalCactusProfileIdOrNull(profileId);
  final fromVariety = _canonicalCactusProfileIdOrNull(varietyId);
  final fromAlias = _canonicalCactusProfileIdOrNull(varietyAlias);

  // Repara contextos históricos donde ca_skip quedó en profileId mientras
  // la selección específica sobrevivía en varietyId/varietyAlias.
  for (final candidate in <String?>[fromVariety, fromProfile, fromAlias]) {
    if (candidate != null && candidate != 'ca_skip') return candidate;
  }
  return fromProfile ?? fromVariety ?? fromAlias ?? 'ca_skip';
}

String _canonicalCactusStageId(String? value) {
  return switch (value?.trim().toLowerCase()) {
    'installation_establishment' ||
    'planned' ||
    'installation' ||
    'repot' ||
    'transplant' => 'installation_establishment',
    'root_establishment' || 'rooting' || 'establishing' => 'root_establishment',
    'active_growth' || 'growing' || 'active' => 'active_growth',
    'maintenance' || 'stable' || 'established' => 'maintenance',
    'rest' || 'dormant' || 'resting' => 'rest',
    _ => 'unknown',
  };
}

String _canonicalCactusVisibleAlias(String? raw, String profileId) {
  final value = raw?.trim();
  final normalized = value?.toLowerCase();
  const internalInputs = <String>{
    'ca_skip',
    'ca-skip',
    'caskip',
    'cactus_generic',
    'ca_01_desert_container',
    'ca-01',
    'ca01',
    'ca_01',
    'cactus_mini',
    'ca_02_barrel_biznaga',
    'ca-02',
    'ca02',
    'ca_02',
    'ca_03_columnar_landscape',
    'ca-03',
    'ca03',
    'ca_03',
    'cactus_columnar',
    'ca_04_clustered_desert',
    'ca-04',
    'ca04',
    'ca_04',
  };
  if (value != null &&
      value.isNotEmpty &&
      !internalInputs.contains(normalized)) {
    return value;
  }
  return switch (profileId) {
    'ca_01_desert_container' => 'Cactus de maceta',
    'ca_02_barrel_biznaga' => 'Biznaga o cactus barril',
    'ca_03_columnar_landscape' => 'Cactus columna u órgano',
    'ca_04_clustered_desert' => 'Cactus agrupado o de varios tallos',
    _ => 'No sé / cactus general',
  };
}
