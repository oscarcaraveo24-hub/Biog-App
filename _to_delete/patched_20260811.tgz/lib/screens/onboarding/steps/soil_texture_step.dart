// lib/screens/onboarding/steps/soil_texture_step.dart
//
// «¿Cómo es tu tierra?» — el selector de material.
//
// ─────────────────────────────────────────────────────────────────────────────
// QUÉ DEBE SENTIRSE AL ABRIR
// ─────────────────────────────────────────────────────────────────────────────
//
// Un selector de materiales de herramienta ag-tech premium: limpio, táctil y
// fácil de entender aunque el productor no conozca un solo término técnico. La
// esfera es la protagonista; el resto de la interfaz explica, no compite. Debe
// sentirse tecnológica por la precisión del movimiento, no por llenar la
// pantalla de efectos.
//
// **El usuario nunca debe sentir que está contestando un examen de agronomía.**
//
// ─────────────────────────────────────────────────────────────────────────────
// UNA SOLA PANTALLA, UN SOLO PASO
// ─────────────────────────────────────────────────────────────────────────────
//
// El selector, las propiedades, los nombres locales y la ayuda de 20 segundos
// pertenecen al mismo paso del wizard. La ayuda abre como hoja inferior interna
// y NO cuenta como otro paso del onboarding: al cerrarla el usuario vuelve al
// carrusel exactamente donde estaba.
//
// ─────────────────────────────────────────────────────────────────────────────
// LO QUE ESTE WIDGET NO HACE
// ─────────────────────────────────────────────────────────────────────────────
//
// · No gira la esfera 360°. Es un PNG plano: girarlo lo delataría.
// · No usa modelado 3D, shaders ni dependencias pesadas.
// · No preselecciona una textura como dato confirmado. Puede *mostrar* Franca
//   como vista inicial, pero no la reporta hasta que hay interacción explícita:
//   quien no toca nada no ha declarado nada.
// · No decide con el color. El color NO define la textura —la definen
//   granulometría, cohesión, porosidad y microgrietas— y por eso la selección
//   se marca con aro, palomita Y texto, nunca solo con verde.

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:bio_g/core/agro/water/soil_texture_source.dart';
import 'package:bio_g/core/agro/water/soil_water_scale.dart';
import 'package:bio_g/theme/bio_g_theme.dart';
import 'package:bio_g/widgets/onboarding/soil_texture_guide_sheet.dart';
import 'package:bio_g/widgets/shared/bio_g_glass_card.dart';

/// Nombres locales opcionales. Registran el lenguaje del productor **sin
/// modificar la clasificación hidráulica**: no cambian SoilTexture, ni la
/// retención, ni el drenaje, ni un solo cálculo del motor.
class SoilLocalDescriptors {
  const SoilLocalDescriptors._();

  static const String red = 'roja';
  static const String limestone = 'blanca_caliza';
  static const String black = 'negra';
  static const String volcanic = 'volcanica';
  static const String other = 'otra';

  static const List<String> all = <String>[
    red,
    limestone,
    black,
    volcanic,
    other,
  ];

  static String labelOf(String id) => switch (id) {
    red => 'Roja',
    limestone => 'Blanca / caliza',
    black => 'Negra',
    volcanic => 'Volcánica',
    other => 'Otra',
    _ => id,
  };

  static Color dotOf(String id) => switch (id) {
    red => const Color(0xFFB2554E),
    limestone => const Color(0xFFDCD9CF),
    black => const Color(0xFF3A3A38),
    volcanic => const Color(0xFF7B5EA7),
    _ => const Color(0xFFAAB4B0),
  };
}

/// Precarga los seis assets. Se llama al entrar al paso —o desde el paso
/// anterior— para que el primer swipe no haga flash.
void precacheSoilTextureAssets(BuildContext context) {
  // Sin `await` dentro del bucle: encadenarlos usaría el `context` después de
  // una brecha asíncrona —lo que `use_build_context_synchronously` prohíbe y
  // lo que revienta de verdad si el usuario sale del paso a media precarga—.
  // Las seis peticiones se lanzan de una vez con el context todavía montado.
  for (final t in SoilTexture.selectable) {
    precacheImage(AssetImage(t.assetPath), context);
  }
}

class SoilTextureStep extends StatefulWidget {
  const SoilTextureStep({
    super.key,
    required this.selectedTextureId,
    required this.onTextureChanged,
    this.localDescriptors = const <String>[],
    this.localOther,
    this.onLocalDescriptorsChanged,
    this.onLocalOtherChanged,
    this.title = '¿Cómo es tu tierra?',
    this.subtitle = 'Desliza para elegir la que más se parece a la tuya.',
    this.showLocalNames = true,
  });

  /// Id ya guardado, o `null` si el productor todavía no ha declarado nada.
  final String? selectedTextureId;

  /// Reporta textura **y procedencia**: manual → `declared`, guía de 20
  /// segundos → `guidedEstimate`, «No estoy seguro» → `unknown`.
  final void Function(SoilTexture texture, SoilTextureSource source)
  onTextureChanged;

  final List<String> localDescriptors;
  final String? localOther;
  final ValueChanged<List<String>>? onLocalDescriptorsChanged;
  final ValueChanged<String?>? onLocalOtherChanged;

  final String title;
  final String subtitle;

  /// La página de Cuenta reusa el mismo widget; los nombres locales se pueden
  /// ocultar allí si la pantalla ya viene cargada.
  final bool showLocalNames;

  @override
  State<SoilTextureStep> createState() => _SoilTextureStepState();
}

class _SoilTextureStepState extends State<SoilTextureStep>
    with TickerProviderStateMixin {
  static const List<SoilTexture> _options = SoilTexture.selectable;

  late final PageController _pageController;
  late final AnimationController _entry;
  late final AnimationController _idle;
  late final AnimationController _halo;

  /// Se crea UNA vez. Construirla en `build` registraría un listener nuevo
  /// sobre `_entry` en cada swipe, cada chip y cada tecla del campo «Otra», y
  /// esos listeners no se sueltan nunca.
  late final Animation<double> _entryCurve;

  late int _index;
  bool _precached = false;

  // ── Por qué hace falta anotar el movimiento programático ──────────────────
  //
  // `PageView.onPageChanged` dispara con CUALQUIER cambio de página: un gesto
  // del usuario, un `animateToPage` y un `jumpToPage` valen lo mismo para él.
  // Sin esta nota pasaban dos cosas, las dos malas:
  //
  //  · Tocar una miniatura reportaba DOS veces —una desde el tap y otra al
  //    asentarse la página—, con dos vibraciones y dos escrituras del borrador.
  //  · Un resultado de la guía de 20 segundos se reportaba como
  //    `guidedEstimate` y, trescientos milisegundos después, la animación al
  //    asentarse lo reescribía como `declared`. La procedencia —lo único que
  //    distingue una estimación por tacto de una declaración en firme— se
  //    perdía siempre.
  //
  // Ahora el reporte ocurre en un solo sitio: cuando la página se asienta.
  SoilTextureSource? _pendingSource;
  bool _pendingSilent = false;
  final TextEditingController _otherController = TextEditingController();

  SoilTexture get _current => _options[_index];

  @override
  void initState() {
    super.initState();

    // Vista inicial: el valor guardado si lo hay; si no, Franca —que es lo que
    // se ve, no lo que se declara—.
    final stored = SoilTexture.fromId(widget.selectedTextureId);
    final storedIndex = widget.selectedTextureId == null
        ? -1
        : _options.indexOf(stored);
    _index = storedIndex >= 0 ? storedIndex : _options.indexOf(SoilTexture.loam);

    _pageController = PageController(
      initialPage: _index,
      viewportFraction: 0.60,
    );

    _entry = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 320),
    )..forward();

    _entryCurve = CurvedAnimation(parent: _entry, curve: Curves.easeOut);

    _idle = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 4300),
    );

    _halo = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 15),
    );

    _otherController.text = widget.localOther ?? '';
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    if (!_precached) {
      _precached = true;
      // Precarga de los seis assets para que el primer swipe no parpadee.
      precacheSoilTextureAssets(context);
    }

    // Reduced Motion: se desactivan flotación y halo, y se conservan solo las
    // transiciones cortas de selección. No es un extra: es requisito.
    final reduceMotion = MediaQuery.maybeOf(context)?.disableAnimations ?? false;
    if (reduceMotion) {
      if (_idle.isAnimating) _idle.stop();
      if (_halo.isAnimating) _halo.stop();
      _entry.value = 1.0;
    } else {
      if (!_idle.isAnimating) _idle.repeat(reverse: true);
      if (!_halo.isAnimating) _halo.repeat();
    }
  }

  @override
  void didUpdateWidget(covariant SoilTextureStep oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.localOther != oldWidget.localOther &&
        (widget.localOther ?? '') != _otherController.text) {
      _otherController.text = widget.localOther ?? '';
    }

    // El padre puede imponer un valor (por ejemplo, el que devuelve la guía de
    // 20 segundos). Solo se anima si de verdad difiere de lo que se ve.
    if (widget.selectedTextureId != oldWidget.selectedTextureId) {
      final incoming = SoilTexture.fromId(widget.selectedTextureId);
      final i = _options.indexOf(incoming);
      if (i >= 0 && i != _index && widget.selectedTextureId != null) {
        _animateTo(i, notify: false);
      }
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    _entry.dispose();
    _idle.dispose();
    _halo.dispose();
    _otherController.dispose();
    super.dispose();
  }

  bool get _reduceMotion =>
      MediaQuery.maybeOf(context)?.disableAnimations ?? false;

  void _animateTo(int i, {bool notify = true}) {
    if (i < 0 || i >= _options.length) return;

    // Tocar la miniatura que YA está en el centro es una interacción explícita
    // y tiene que declarar esa textura. Sin esto, el usuario que se conforma
    // con la vista inicial —Franca— no tenía forma de aceptarla: el carrusel no
    // cambia de página, `onPageChanged` no dispara, y «Usar esta tierra» se
    // quedaba deshabilitado para siempre. Había que irse a otra esfera y
    // volver, que es un callejón sin salida sin señal alguna.
    if (i == _index) {
      if (!notify) return;
      final texture = _options[i];
      final source = _pendingSource ?? _sourceFor(texture);
      _pendingSource = null;
      HapticFeedback.lightImpact();
      widget.onTextureChanged(texture, source);
      return;
    }

    if (!notify) _pendingSilent = true;

    if (!_pageController.hasClients) {
      _onPageSettled(i);
      return;
    }

    if (_reduceMotion) {
      _pageController.jumpToPage(i);
    } else {
      _pageController.animateToPage(
        i,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
      );
    }
    // El reporte lo hace `_onPageSettled` desde `onPageChanged`.
  }

  /// El ÚNICO sitio que reporta una selección.
  ///
  /// `onPageChanged` no dispara en el primer build —`PageView` inicializa su
  /// última página reportada con `initialPage`—, así que llegar aquí siempre
  /// significa que algo cambió: un gesto, un tap en una miniatura, una flecha o
  /// la guía. Ninguno de esos es "el estado inicial".
  void _onPageSettled(int i) {
    setState(() => _index = i);

    if (_pendingSilent) {
      _pendingSilent = false;
      _pendingSource = null;
      return;
    }

    final texture = _options[i];
    final source = _pendingSource ?? _sourceFor(texture);
    _pendingSource = null;

    HapticFeedback.lightImpact();
    widget.onTextureChanged(texture, source);
  }

  static SoilTextureSource _sourceFor(SoilTexture texture) =>
      texture == SoilTexture.unknown
      ? SoilTextureSource.unknown
      : SoilTextureSource.declared;

  Future<void> _openGuide() async {
    final result = await showSoilTextureGuideSheet(context);
    if (result == null || !mounted) return;

    final i = _options.indexOf(result);
    if (i < 0) return;

    // La guía marca su propia procedencia: es una aproximación de campo, no una
    // clasificación de laboratorio, y el historial tiene que poder distinguirlo.
    // `_animateTo` consume esta nota tanto si la página cambia como si la
    // textura estimada resulta ser la que ya se estaba viendo.
    _pendingSource = SoilTextureSource.guidedEstimate;
    _animateTo(i);
  }

  void _toggleLocal(String id) {
    final next = List<String>.of(widget.localDescriptors);
    if (next.contains(id)) {
      next.remove(id);
      if (id == SoilLocalDescriptors.other) {
        _otherController.clear();
        widget.onLocalOtherChanged?.call(null);
      }
    } else {
      next.add(id);
    }
    HapticFeedback.selectionClick();
    widget.onLocalDescriptorsChanged?.call(next);
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);

    // La esfera se ajusta por altura disponible. Fijar un tamaño provocaría
    // overflow en pantallas pequeñas, que es justo lo que no puede pasar.
    final heroSize = math
        .min(media.size.width * 0.52, media.size.height * 0.24)
        .clamp(120.0, 208.0);
    final heroBoxHeight = heroSize + 44;

    return FadeTransition(
      opacity: _entryCurve,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          _Title(text: widget.title, entry: _entry),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              widget.subtitle,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14.2,
                height: 1.34,
                color: Colors.black.withValues(alpha: 0.45),
              ),
            ),
          ),
          const SizedBox(height: 14),

          // ── Hero ────────────────────────────────────────────────────────────
          SizedBox(
            height: heroBoxHeight,
            child: Stack(
              alignment: Alignment.center,
              children: <Widget>[
                PageView.builder(
                  controller: _pageController,
                  itemCount: _options.length,
                  onPageChanged: _onPageSettled,
                  itemBuilder: (context, i) {
                    return _HeroSphere(
                      texture: _options[i],
                      pageController: _pageController,
                      page: i,
                      size: heroSize,
                      idle: _idle,
                      halo: _halo,
                      entry: _entry,
                      reduceMotion: _reduceMotion,
                      isFocused: i == _index,
                    );
                  },
                ),
                Positioned(
                  left: 2,
                  child: _ArrowButton(
                    icon: Icons.chevron_left_rounded,
                    tooltip: 'Anterior',
                    onTap: _index > 0 ? () => _animateTo(_index - 1) : null,
                  ),
                ),
                Positioned(
                  right: 2,
                  child: _ArrowButton(
                    icon: Icons.chevron_right_rounded,
                    tooltip: 'Siguiente',
                    onTap: _index < _options.length - 1
                        ? () => _animateTo(_index + 1)
                        : null,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 6),
          _Dots(count: _options.length, index: _index),
          const SizedBox(height: 12),

          // ── Nombre + label pequeño ──────────────────────────────────────────
          _NameBlock(texture: _current),
          const SizedBox(height: 14),

          // ── Propiedades ─────────────────────────────────────────────────────
          _PropertiesRow(texture: _current),
          const SizedBox(height: 16),

          // ── Mini carrusel ───────────────────────────────────────────────────
          _MiniCarousel(
            options: _options,
            index: _index,
            onTap: _animateTo,
          ),

          if (widget.showLocalNames) ...<Widget>[
            const SizedBox(height: 18),
            _LocalNamesBlock(
              selected: widget.localDescriptors,
              onToggle: _toggleLocal,
              otherController: _otherController,
              onOtherChanged: widget.onLocalOtherChanged,
            ),
          ],

          const SizedBox(height: 16),
          _HelpRow(onTap: _openGuide),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Piezas
// ═══════════════════════════════════════════════════════════════════════════

class _Title extends StatelessWidget {
  const _Title({required this.text, required this.entry});

  final String text;
  final AnimationController entry;

  @override
  Widget build(BuildContext context) {
    // Entrada: fade + desplazamiento corto. Jerarquía sin "show".
    return AnimatedBuilder(
      animation: entry,
      builder: (context, child) {
        final t = Curves.easeOut.transform(entry.value);
        return Transform.translate(
          offset: Offset(0, (1 - t) * 10),
          child: Opacity(opacity: t, child: child),
        );
      },
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontSize: 23,
          height: 1.16,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.4,
          color: BioGTheme.charcoal,
        ),
      ),
    );
  }
}

class _HeroSphere extends StatelessWidget {
  const _HeroSphere({
    required this.texture,
    required this.pageController,
    required this.page,
    required this.size,
    required this.idle,
    required this.halo,
    required this.entry,
    required this.reduceMotion,
    required this.isFocused,
  });

  final SoilTexture texture;
  final PageController pageController;
  final int page;
  final double size;
  final AnimationController idle;
  final AnimationController halo;
  final AnimationController entry;
  final bool reduceMotion;
  final bool isFocused;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge(<Listenable>[
        pageController,
        idle,
        halo,
        entry,
      ]),
      builder: (context, _) {
        // Distancia al centro del viewport: 0 = protagonista, 1 = vecina.
        double delta = 0;
        if (pageController.hasClients && pageController.position.haveDimensions) {
          delta = ((pageController.page ?? page.toDouble()) - page).abs();
        }
        final focus = (1.0 - delta).clamp(0.0, 1.0);

        // Swipe: la saliente encoge a 0.92 y se desvanece; la entrante crece.
        // No hay morph de píxeles: transición cruzada + escala + desplazamiento.
        final scale = 0.92 + 0.08 * focus;
        final opacity = 0.35 + 0.65 * focus;

        // Idle: flotación vertical mínima y escala 1.00↔1.01. Evita que parezca
        // una foto pegada; nunca llama la atención.
        final wave = reduceMotion
            ? 0.0
            : math.sin(idle.value * math.pi * 2) * focus;
        final floatY = wave * 3.0;
        final breathe = 1.0 + wave.abs() * 0.01;

        final entryT = Curves.easeOut.transform(entry.value);
        final entryScale = 0.94 + 0.06 * entryT;

        return Center(
          child: Opacity(
            opacity: opacity,
            child: Transform.scale(
              scale: scale * breathe * (isFocused ? entryScale : 1.0),
              child: SizedBox(
                width: size + 26,
                height: size + 40,
                child: Stack(
                  alignment: Alignment.center,
                  children: <Widget>[
                    // Halo tecnológico: arco verde parcial, giro lento e
                    // independiente. Ambiente, no protagonismo.
                    if (!reduceMotion && focus > 0.55)
                      Transform.rotate(
                        angle: halo.value * 2 * math.pi,
                        child: CustomPaint(
                          size: Size(size + 22, size + 22),
                          painter: _HaloPainter(
                            opacity: (focus - 0.55) / 0.45,
                          ),
                        ),
                      ),

                    // Sombra: óvalo difuso sincronizado con la flotación.
                    Positioned(
                      bottom: 2,
                      child: Opacity(
                        opacity: (0.16 + 0.06 * wave.abs()) * focus,
                        child: Container(
                          width: size * (0.62 - 0.04 * wave.abs()),
                          height: size * 0.10,
                          decoration: BoxDecoration(
                            color: Colors.black,
                            borderRadius: BorderRadius.circular(size),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.18),
                                blurRadius: 18,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    Transform.translate(
                      offset: Offset(0, floatY),
                      child: Semantics(
                        image: true,
                        label:
                            '${texture.displayNameEs}. '
                            '${texture.shortLabelEs}. '
                            'Retención de agua ${texture.waterRetention05} de 5. '
                            'Drenaje ${texture.drainage05} de 5.',
                        child: Image.asset(
                          texture.assetPath,
                          width: size,
                          height: size,
                          fit: BoxFit.contain,
                          filterQuality: FilterQuality.medium,
                          errorBuilder: (_, _, _) => _AssetFallback(size: size),
                        ),
                      ),
                    ),

                    if (texture == SoilTexture.unknown)
                      Transform.translate(
                        offset: Offset(0, floatY),
                        child: Text(
                          '?',
                          style: TextStyle(
                            fontSize: size * 0.34,
                            fontWeight: FontWeight.w800,
                            color: BioGTheme.green800.withValues(alpha: 0.92),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _AssetFallback extends StatelessWidget {
  const _AssetFallback({required this.size});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            const Color(0xFFB79B7C),
            const Color(0xFF6E5843).withValues(alpha: 0.9),
          ],
        ),
      ),
    );
  }
}

class _HaloPainter extends CustomPainter {
  _HaloPainter({required this.opacity});

  final double opacity;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final center = rect.center;
    final radius = size.width / 2;

    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round
      ..color = BioGTheme.green500.withValues(alpha: 0.42 * opacity);

    // Arco parcial, no anillo completo: sugiere instrumento, no holograma.
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -math.pi * 0.85,
      math.pi * 0.72,
      false,
      arc,
    );

    final tick = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..strokeCap = StrokeCap.round
      ..color = BioGTheme.green500.withValues(alpha: 0.30 * opacity);

    for (var i = 0; i < 3; i++) {
      final a = math.pi * (0.24 + i * 0.09);
      final p1 = Offset(
        center.dx + math.cos(a) * radius,
        center.dy + math.sin(a) * radius,
      );
      final p2 = Offset(
        center.dx + math.cos(a) * (radius - 6),
        center.dy + math.sin(a) * (radius - 6),
      );
      canvas.drawLine(p1, p2, tick);
    }
  }

  @override
  bool shouldRepaint(covariant _HaloPainter oldDelegate) =>
      oldDelegate.opacity != opacity;
}

class _ArrowButton extends StatelessWidget {
  const _ArrowButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return Semantics(
      button: true,
      enabled: enabled,
      label: tooltip,
      child: Material(
        color: Colors.white.withValues(alpha: enabled ? 0.94 : 0.55),
        shape: const CircleBorder(),
        elevation: enabled ? 2 : 0,
        shadowColor: Colors.black.withValues(alpha: 0.14),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          // Objetivo táctil mínimo 44×44, incluso con el círculo visual menor.
          child: SizedBox(
            width: 44,
            height: 44,
            child: Icon(
              icon,
              size: 24,
              color: enabled
                  ? BioGTheme.charcoal.withValues(alpha: 0.72)
                  : BioGTheme.charcoal.withValues(alpha: 0.24),
            ),
          ),
        ),
      ),
    );
  }
}

class _Dots extends StatelessWidget {
  const _Dots({required this.count, required this.index});

  final int count;
  final int index;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List<Widget>.generate(count, (i) {
        final on = i == index;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: on ? 7 : 5,
          height: on ? 7 : 5,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: on
                ? BioGTheme.green800.withValues(alpha: 0.85)
                : Colors.black.withValues(alpha: 0.14),
          ),
        );
      }),
    );
  }
}

class _NameBlock extends StatelessWidget {
  const _NameBlock({required this.texture});

  final SoilTexture texture;

  @override
  Widget build(BuildContext context) {
    final isUnknown = texture == SoilTexture.unknown;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 200),
      child: Column(
        key: ValueKey<SoilTexture>(texture),
        children: <Widget>[
          Text(
            texture.displayNameEs,
            textAlign: TextAlign.center,
            // Nombres como «Franco-arenosa» no se truncan: se envuelven.
            softWrap: true,
            style: const TextStyle(
              fontSize: 25,
              height: 1.14,
              fontWeight: FontWeight.w700,
              letterSpacing: -0.5,
              color: BioGTheme.charcoal,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 6,
            runSpacing: 6,
            children: <Widget>[
              if (!isUnknown) _Chip(text: texture.shortLabelEs),
              if (!isUnknown) _Chip(text: _balanceWord(texture)),
            ],
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              isUnknown
                  // Subtítulo honesto: es literalmente cierto. El resolver cae a
                  // media, lo marca como respaldo y resta confianza; nada de eso
                  // se esconde ni se atenúa.
                  ? 'BIO-G usará una tierra media y te lo dirá cuando '
                        'recomiende riego. Puedes cambiarlo cuando lo sepas.'
                  : texture.fieldHintEs,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 13.6,
                height: 1.42,
                color: Colors.black.withValues(alpha: 0.52),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Palabra de equilibrio, derivada de las propiedades. No es una tercera
  /// fuente de verdad: sale de los mismos dos números que ya se pintan.
  static String _balanceWord(SoilTexture t) {
    final diff = t.drainage05 - t.waterRetention05;
    if (diff >= 3) return 'Drena mucho';
    if (diff >= 1) return 'Suelta';
    if (diff <= -3) return 'Retiene mucho';
    if (diff <= -1) return 'Compacta';
    return 'Equilibrada';
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 5),
      decoration: BoxDecoration(
        color: BioGTheme.green200.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 12.2,
          fontWeight: FontWeight.w600,
          color: BioGTheme.green700,
        ),
      ),
    );
  }
}

class _PropertiesRow extends StatelessWidget {
  const _PropertiesRow({required this.texture});

  final SoilTexture texture;

  @override
  Widget build(BuildContext context) {
    if (texture == SoilTexture.unknown) {
      // Con «No estoy seguro» NO se pintan 3/5 y 3/5 como si fueran verdad.
      // Mostrar los números de la media aquí sería inventar una lectura que el
      // productor no dio.
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: BioGGlassCard(
          radius: 18,
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
          child: Row(
            children: <Widget>[
              Icon(
                Icons.help_outline_rounded,
                size: 18,
                color: BioGTheme.green700.withValues(alpha: 0.8),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Retención y drenaje: variable hasta que lo sepas.',
                  style: TextStyle(
                    fontSize: 12.8,
                    height: 1.35,
                    color: Color(0xFF66747C),
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Row(
        children: <Widget>[
          Expanded(
            child: _PropertyCard(
              // Se reutiliza el icono de humedad que ya existe en la app: no se
              // crea un juego de iconos nuevo para esta pantalla.
              iconAsset: 'assets/icons/metrics/ic_moisture.png',
              fallbackIcon: Icons.water_drop_rounded,
              title: 'Retención de agua',
              level: texture.waterRetention05,
              color: const Color(0xFF3E8FD0),
              caption: _levelWord(texture.waterRetention05),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: _PropertyCard(
              iconAsset: 'assets/icons/metrics/ic_riego.png',
              fallbackIcon: Icons.filter_alt_outlined,
              title: 'Drenaje',
              level: texture.drainage05,
              color: BioGTheme.green800,
              caption: _levelWord(texture.drainage05),
            ),
          ),
        ],
      ),
    );
  }

  static String _levelWord(int level) => switch (level) {
    <= 1 => 'Bajo',
    2 => 'Medio – bajo',
    3 => 'Medio',
    4 => 'Medio – alto',
    _ => 'Alto',
  };
}

class _PropertyCard extends StatelessWidget {
  const _PropertyCard({
    required this.iconAsset,
    required this.fallbackIcon,
    required this.title,
    required this.level,
    required this.color,
    required this.caption,
  });

  final String iconAsset;
  final IconData fallbackIcon;
  final String title;
  final int level;
  final Color color;
  final String caption;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      label: '$title: $level de 5, $caption',
      excludeSemantics: true,
      child: BioGGlassCard(
        radius: 18,
        padding: const EdgeInsets.fromLTRB(12, 11, 12, 11),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                Image.asset(
                  iconAsset,
                  width: 16,
                  height: 16,
                  cacheWidth: 48,
                  errorBuilder: (_, _, _) =>
                      Icon(fallbackIcon, size: 16, color: color),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 2,
                    style: const TextStyle(
                      fontSize: 11.6,
                      height: 1.2,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF5A6B6F),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 9),
            Row(
              children: List<Widget>.generate(5, (i) {
                final on = i < level;
                return Container(
                  margin: const EdgeInsets.only(right: 5),
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: on
                        ? color.withValues(alpha: 0.92)
                        : Colors.black.withValues(alpha: 0.10),
                  ),
                );
              }),
            ),
            const SizedBox(height: 7),
            Text(
              caption,
              style: TextStyle(
                fontSize: 11.4,
                color: Colors.black.withValues(alpha: 0.42),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniCarousel extends StatelessWidget {
  const _MiniCarousel({
    required this.options,
    required this.index,
    required this.onTap,
  });

  final List<SoilTexture> options;
  final int index;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 92,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        itemCount: options.length,
        separatorBuilder: (_, _) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final t = options[i];
          final selected = i == index;
          return _MiniItem(
            texture: t,
            selected: selected,
            onTap: () => onTap(i),
          );
        },
      ),
    );
  }
}

class _MiniItem extends StatefulWidget {
  const _MiniItem({
    required this.texture,
    required this.selected,
    required this.onTap,
  });

  final SoilTexture texture;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_MiniItem> createState() => _MiniItemState();
}

class _MiniItemState extends State<_MiniItem>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 190),
    lowerBound: 0,
    upperBound: 1,
  );

  @override
  void didUpdateWidget(covariant _MiniItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Confirmación visual: aro verde + micro escala 1.00 → 1.04 → 1.00.
    if (widget.selected && !oldWidget.selected) {
      _pulse.forward(from: 0).then((_) {
        if (mounted) _pulse.reverse();
      });
    }
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.texture;
    final isUnknown = t == SoilTexture.unknown;

    return Semantics(
      button: true,
      selected: widget.selected,
      label: '${t.displayNameEs}, ${t.shortLabelEs}',
      excludeSemantics: true,
      child: GestureDetector(
        onTap: widget.onTap,
        behavior: HitTestBehavior.opaque,
        child: AnimatedBuilder(
          animation: _pulse,
          builder: (context, child) => Transform.scale(
            scale: 1.0 + 0.04 * _pulse.value,
            child: child,
          ),
          child: SizedBox(
            // Ancho generoso para que «Franco-arenosa» pueda envolver a otra
            // línea sin truncarse. Alto ≥ 44 para el objetivo táctil.
            width: 74,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Stack(
                  clipBehavior: Clip.none,
                  alignment: Alignment.center,
                  children: <Widget>[
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 50,
                      height: 50,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isUnknown
                            ? const Color(0xFFF1F4F3)
                            : Colors.transparent,
                        border: Border.all(
                          color: widget.selected
                              ? BioGTheme.green800.withValues(alpha: 0.9)
                              : Colors.transparent,
                          width: 2,
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(3),
                        child: isUnknown
                            ? Center(
                                child: Text(
                                  '?',
                                  style: TextStyle(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w800,
                                    color: BioGTheme.green800.withValues(
                                      alpha: 0.85,
                                    ),
                                  ),
                                ),
                              )
                            // Mismo asset que el hero, reducido. No hay un segundo
                            // juego de imágenes, y `cacheWidth` evita decodificar
                            // 1024 px seis veces en una fila pequeña.
                            : Image.asset(
                                t.assetPath,
                                cacheWidth: 132,
                                fit: BoxFit.contain,
                                errorBuilder: (_, _, _) =>
                                    const _AssetFallback(size: 40),
                              ),
                      ),
                    ),
                    // Aro, palomita Y texto. La selección NO puede depender
                    // solo del color verde: es requisito de accesibilidad, no
                    // adorno. Va en un `Stack` y no en la columna porque
                    // `Transform.translate` desplaza el pintado pero no encoge
                    // la caja: sumaba 16 px al alto y desbordaba la fila.
                    if (widget.selected)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: Container(
                          width: 16,
                          height: 16,
                          decoration: const BoxDecoration(
                            shape: BoxShape.circle,
                            color: BioGTheme.green800,
                          ),
                          child: const Icon(
                            Icons.check_rounded,
                            size: 11,
                            color: Colors.white,
                          ),
                        ),
                      ),
                  ],
                ),

                const SizedBox(height: 5),
                Text(
                  isUnknown ? 'No estoy\nseguro' : t.displayNameEs,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  style: TextStyle(
                    fontSize: 10.4,
                    height: 1.14,
                    fontWeight: widget.selected
                        ? FontWeight.w700
                        : FontWeight.w500,
                    color: widget.selected
                        ? BioGTheme.charcoal
                        : Colors.black.withValues(alpha: 0.46),
                  ),
                ),
                if (!isUnknown)
                  Text(
                    t.shortLabelEs,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    style: TextStyle(
                      fontSize: 9.6,
                      color: Colors.black.withValues(alpha: 0.34),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LocalNamesBlock extends StatelessWidget {
  const _LocalNamesBlock({
    required this.selected,
    required this.onToggle,
    required this.otherController,
    required this.onOtherChanged,
  });

  final List<String> selected;
  final ValueChanged<String> onToggle;
  final TextEditingController otherController;
  final ValueChanged<String?>? onOtherChanged;

  @override
  Widget build(BuildContext context) {
    final showOther = selected.contains(SoilLocalDescriptors.other);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: BioGGlassCard(
        radius: 18,
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                const Text(
                  '¿La conoces por otro nombre?',
                  style: TextStyle(
                    fontSize: 12.8,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF5A6B6F),
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '(opcional)',
                  style: TextStyle(
                    fontSize: 11.2,
                    color: Colors.black.withValues(alpha: 0.34),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 7,
              runSpacing: 7,
              children: SoilLocalDescriptors.all.map((id) {
                final on = selected.contains(id);
                return _LocalChip(
                  id: id,
                  selected: on,
                  onTap: () => onToggle(id),
                );
              }).toList(),
            ),
            if (showOther) ...<Widget>[
              const SizedBox(height: 10),
              TextField(
                controller: otherController,
                onChanged: (v) => onOtherChanged?.call(v.trim().isEmpty ? null : v.trim()),
                textCapitalization: TextCapitalization.sentences,
                style: const TextStyle(fontSize: 13.4),
                decoration: InputDecoration(
                  isDense: true,
                  hintText: 'Ej. tierra colorada',
                  hintStyle: TextStyle(
                    fontSize: 13,
                    color: Colors.black.withValues(alpha: 0.30),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: Colors.black.withValues(alpha: 0.08),
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: Colors.black.withValues(alpha: 0.08),
                    ),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 8),
            Text(
              // Advertencia deliberada: el nombre local es contexto, no
              // clasificación. No cambia SoilTexture ni un número del motor.
              'Solo es para reconocerla. No cambia los cálculos de BIO-G.',
              style: TextStyle(
                fontSize: 10.8,
                height: 1.3,
                color: Colors.black.withValues(alpha: 0.32),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LocalChip extends StatelessWidget {
  const _LocalChip({
    required this.id,
    required this.selected,
    required this.onTap,
  });

  final String id;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      selected: selected,
      label: SoilLocalDescriptors.labelOf(id),
      excludeSemantics: true,
      child: Material(
        color: selected
            ? BioGTheme.green200.withValues(alpha: 0.95)
            : const Color(0xFFF4F6F5),
        borderRadius: BorderRadius.circular(999),
        child: InkWell(
          borderRadius: BorderRadius.circular(999),
          onTap: onTap,
          child: Container(
            constraints: const BoxConstraints(minHeight: 34),
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              border: Border.all(
                color: selected
                    ? BioGTheme.green800.withValues(alpha: 0.55)
                    : Colors.transparent,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: SoilLocalDescriptors.dotOf(id),
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  SoilLocalDescriptors.labelOf(id),
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                    color: selected
                        ? BioGTheme.green700
                        : const Color(0xFF66747C),
                  ),
                ),
                if (selected) ...<Widget>[
                  const SizedBox(width: 5),
                  const Icon(
                    Icons.check_rounded,
                    size: 13,
                    color: BioGTheme.green700,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _HelpRow extends StatelessWidget {
  const _HelpRow({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Material(
        color: const Color(0xFFF3F7F4),
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: Container(
            constraints: const BoxConstraints(minHeight: 54),
            padding: const EdgeInsets.fromLTRB(14, 10, 12, 10),
            child: Row(
              children: <Widget>[
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: BioGTheme.green200.withValues(alpha: 0.9),
                  ),
                  child: const Icon(
                    Icons.timer_outlined,
                    size: 17,
                    color: BioGTheme.green700,
                  ),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text(
                        '¿No sabes cuál elegir?',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: BioGTheme.charcoal,
                        ),
                      ),
                      SizedBox(height: 2),
                      Text(
                        'Identifica tu tierra en 20 segundos con 3 preguntas.',
                        style: TextStyle(
                          fontSize: 11.6,
                          height: 1.25,
                          color: Color(0xFF66747C),
                        ),
                      ),
                    ],
                  ),
                ),
                const Text(
                  'Probar ahora',
                  style: TextStyle(
                    fontSize: 12.2,
                    fontWeight: FontWeight.w700,
                    color: BioGTheme.green700,
                  ),
                ),
                const Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: BioGTheme.green700,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
